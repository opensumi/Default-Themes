// GENERATE BY ./scripts/yuque-crawler.js
// DON NOT EDIT IT MANUALLY
module.exports = Object.assign(
  {},
  require('./basic.json'),
  require('./button.json'),
  require('./input.json'),
  require('./select.json'),
  require('./checkbox.json'),
  require('./tree.json'),
  require('./modal.json'),
  require('./notification.json'),
  require('./message.json'),
  require('./popover.json'),
  require('./tooltip.json'),
  require('./actionbar.json'),
  require('./tab.json'),
  require('./menubar.json'),
  require('./statusbar.json'),
  require('./activitybar.json'),
  require('./sidebar.json'),
  require('./explorer.json'),
  require('./extensions.json'),
  require('./search.json'),
  require('./editor.json'),
  require('./panel.json'),
  require('./setting.json'),
  require('./keybinding.json')
)
